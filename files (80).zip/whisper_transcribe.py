"""whisper_transcribe.py ― 音声文字起こし 1ファイル版（実務用・全行コメント付き）
使い方:
  python whisper_transcribe.py 会議.mp3 --engine local               # 外部に送らない（CPU / small）
  python whisper_transcribe.py 会議.mp3 --engine openai              # OpenAI API
  python whisper_transcribe.py 会議.mp3 --engine azure               # Azure OpenAI
  python whisper_transcribe.py ./rec --engine local --model large-v3 --device cuda
"""
import argparse                                   # コマンドライン引数を解析する標準ライブラリ
import os                                         # 環境変数（APIキーなど）を読むための標準ライブラリ
import shutil                                     # ffmpeg がインストール済みか調べるために使う
import subprocess                                 # ffmpeg を外部コマンドとして呼び出すために使う
import sys                                        # エラーメッセージを出して終了（sys.exit）するために使う
import tempfile                                   # 分割した音声の置き場（一時フォルダ）を作るために使う
from pathlib import Path                          # ファイルパスを、文字列より安全に扱うためのクラス

from dotenv import load_dotenv                    # .env ファイルから環境変数を読み込む関数

MAX_BYTES = 25 * 1024 * 1024                      # API の1ファイル上限（25MB）をバイト数で定義
SPLIT_SECONDS = 600                               # 上限を超えたとき、何秒ごとに分割するか（10分）
AUDIO_EXT = {".mp3", ".wav", ".m4a", ".mp4", ".webm", ".ogg", ".flac"}  # 対象とする音声の拡張子


def collect_files(target: str) -> list[Path]:     # 入力（ファイルまたはフォルダ）から処理対象を集める関数
    p = Path(target)                              # 文字列を Path オブジェクトに変換する
    if not p.exists():                            # 指定した場所が存在しない場合は、
        sys.exit(f"[エラー] 見つかりません: {p}")  # 理由を表示してプログラムを終了する
    if p.is_file():                               # 1つのファイルが指定された場合は、
        return [p]                                # そのファイルだけのリストを返す
    files = sorted(                               # フォルダの場合は、中の音声ファイルを名前順に並べる
        f for f in p.iterdir()                    # フォルダ内の全ての項目を1つずつ取り出し、
        if f.suffix.lower() in AUDIO_EXT          # 拡張子が音声のものだけを残す（大文字小文字は無視）
    )                                             # 名前順の並べ替えで、分割ファイルの順序が保たれる
    if not files:                                 # 音声ファイルが1つも無い場合は、
        sys.exit(f"[エラー] 音声ファイルがありません: {p}")  # 理由を表示して終了する
    return files                                  # 集めたファイルのリストを返す


def split_audio(src: Path, out_dir: Path) -> list[Path]:  # 25MB 超の音声を分割する関数（ffmpeg が必要）
    if shutil.which("ffmpeg") is None:            # ffmpeg が PATH に見つからない場合は、
        sys.exit("[エラー] ffmpeg がありません。winget install Gyan.FFmpeg の後、VSCode を再起動")  # 案内して終了
    out_dir.mkdir(parents=True, exist_ok=True)    # 分割ファイルの置き場フォルダを作る（既にあってもよい）
    subprocess.run(                               # ffmpeg を実行する
        [                                         # コマンドを「単語のリスト」で渡す（空白やスペースに強い）
            "ffmpeg", "-y", "-loglevel", "error", # 上書き許可、ログはエラーだけにする
            "-i", str(src),                       # 入力ファイルを指定する
            "-vn", "-ac", "1",                    # 映像を捨て、音声をモノラルにする（容量削減）
            "-c:a", "libmp3lame", "-b:a", "64k",  # mp3 の 64kbps に変換する（10分で約5MB）
            "-f", "segment",                      # 出力を複数ファイルに分割する方式にする
            "-segment_time", str(SPLIT_SECONDS),  # 指定秒数ごとに区切る
            "-reset_timestamps", "1",             # 各ファイルの時刻を 0 から始め直す
            str(out_dir / "part_%03d.mp3"),       # 出力名（part_000.mp3, part_001.mp3, ...）
        ],                                        # コマンドのリストはここまで
        check=True,                               # ffmpeg が失敗したら例外を出して気づけるようにする
    )                                             # subprocess.run の呼び出しはここまで
    parts = sorted(out_dir.glob("part_*.mp3"))    # 作られた分割ファイルを名前順に集める
    return [p for p in parts if p.stat().st_size >= 2048]  # 末尾にできる極小ファイルは除外して返す


def build_api_client(engine: str):                # API 用のクライアント（接続オブジェクト）を作る関数
    if engine == "openai":                        # OpenAI API を使う場合
        if not os.environ.get("OPENAI_API_KEY"):  # APIキーが設定されていなければ、
            sys.exit("[エラー] OPENAI_API_KEY がありません（.env を確認）")  # 案内して終了する
        from openai import OpenAI                 # 必要になった時点で OpenAI ライブラリを読み込む
        return OpenAI(timeout=120, max_retries=3) # 120秒でタイムアウト、失敗時は自動で3回まで再試行
    need = ["AZURE_OPENAI_ENDPOINT", "AZURE_OPENAI_DEPLOYMENT"]  # Azure で必須の設定名を並べる
    if os.environ.get("USE_ENTRA") != "1":        # キーレス認証（Entra ID）を使わない場合は、
        need.append("AZURE_OPENAI_API_KEY")       # APIキーも必須にする
    missing = [k for k in need if not os.environ.get(k)]  # 未設定の項目を洗い出す
    if missing:                                   # 1つでも足りなければ、
        sys.exit(f"[エラー] .env に未設定: {', '.join(missing)}")  # 足りない名前を表示して終了する
    from openai import AzureOpenAI                # Azure 用のクライアントクラスを読み込む
    common = dict(                                # 2つの認証方式で共通の設定をまとめる
        azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],  # 自分の Azure リソースのURL
        api_version=os.environ.get("AZURE_OPENAI_API_VERSION", "2024-02-01"),  # API版（未設定なら既定値）
        timeout=120, max_retries=3,               # タイムアウトと自動再試行の設定
    )                                             # 共通設定はここまで
    if os.environ.get("USE_ENTRA") == "1":        # キーレス認証（Entra ID）を選んだ場合
        from azure.identity import DefaultAzureCredential, get_bearer_token_provider  # 認証用の部品を読み込む
        provider = get_bearer_token_provider(     # 利用者のログイン情報から、アクセストークンの取得係を作る
            DefaultAzureCredential(),             # 環境に応じて、利用可能な認証方法を自動で選ぶ
            "https://cognitiveservices.azure.com/.default",  # トークンを使うサービスの範囲（スコープ）
        )                                         # トークン取得係の作成はここまで
        return AzureOpenAI(azure_ad_token_provider=provider, **common)  # キーの代わりにトークン取得係を渡す
    return AzureOpenAI(api_key=os.environ["AZURE_OPENAI_API_KEY"], **common)  # APIキー方式のクライアントを返す


def transcribe_api(client, model: str, path: Path, prompt: str | None) -> str:  # API で1ファイルを文字起こしする関数
    with path.open("rb") as fp:                   # 音声ファイルをバイナリ（rb）で開く。使い終わると自動で閉じる
        kwargs = {"model": model, "file": fp, "language": "ja"}  # 送る設定：モデル名・音声・言語（日本語）
        if prompt:                                # 用語ヒントが指定されていれば、
            kwargs["prompt"] = prompt             # それも一緒に送る（専門用語の誤認識を減らす）
        return client.audio.transcriptions.create(**kwargs).text  # API を呼び、結果の文字列だけを返す


def transcribe_local(model, path: Path, prompt: str | None, vad: bool) -> list[str]:  # 手元のPCで文字起こしする関数
    segments, _info = model.transcribe(           # モデルに音声を渡す（結果は区間ごとの「遅延リスト」）
        str(path), language="ja", beam_size=5,    # ファイルパス・日本語・探索幅5（精度と速度のバランス）
        vad_filter=vad,                           # 無音区間を除き、無音での誤認識（幻覚）を減らす
        initial_prompt=prompt,                    # 用語ヒント（None なら何も渡さない）
    )                                             # この時点では、まだ文字起こしは終わっていない
    return [                                      # 区間を1つずつ取り出して、文字列のリストにする
        f"[{s.start:7.1f}s - {s.end:7.1f}s] {s.text.strip()}"  # 「[開始秒 - 終了秒] テキスト」の形式
        for s in segments                         # ここで実際に文字起こしが進む（イテレーションで実行）
    ]                                             # 全区間を取り出し終えたら、リストを返す


def main() -> None:                               # プログラムの入口（全体の流れを組み立てる）
    ap = argparse.ArgumentParser(description="音声文字起こし（Whisper）")  # 引数の解析器を作る
    ap.add_argument("target", help="音声ファイル or フォルダ")  # 必須の引数：処理する対象
    ap.add_argument("--engine", choices=["local", "openai", "azure"], default="local",  # 使う方式（既定は local）
                    help="local=外部送信なし / openai / azure")  # --help に出す説明
    ap.add_argument("--model", default="small", help="local用: small / medium / large-v3 など")  # ローカルのモデル名
    ap.add_argument("--device", default="cpu", choices=["cpu", "cuda"])  # ローカルの実行装置（GPUはcuda）
    ap.add_argument("--prompt", default=None, help="専門用語のヒント（例: 'Azure, VSCode'）")  # 用語ヒント
    ap.add_argument("--no-vad", action="store_true", help="無音除去(VAD)を切る")  # 指定すると VAD を無効化
    args = ap.parse_args()                        # 実際のコマンドライン引数を解析して、args に入れる

    load_dotenv()                                 # .env があれば読み込み、環境変数として使えるようにする
    files = collect_files(args.target)            # 処理対象のファイルを集める
    sections: list[tuple[str, str]] = []          # 「(ファイル名, 文字起こし結果)」を貯めるリスト

    if args.engine == "local":                    # --- ローカル方式（音声を外部に送らない） ---
        from faster_whisper import WhisperModel   # 必要になった時点でライブラリを読み込む
        compute = "float16" if args.device == "cuda" else "int8"  # GPUなら float16、CPUなら int8（軽量）
        print(f"モデル読み込み: {args.model} / {args.device} / {compute}（初回はダウンロードあり）")  # 進捗表示
        model = WhisperModel(args.model, device=args.device, compute_type=compute)  # モデルを読み込む
        for f in files:                           # ファイルを1つずつ処理する
            print(f"処理中: {f.name}")            # どのファイルを処理中か表示する
            lines = transcribe_local(model, f, args.prompt, not args.no_vad)  # 文字起こしを実行する
            sections.append((f.name, "\n".join(lines)))  # 結果を、改行でつないで保存する
    else:                                         # --- API方式（音声が外部サービスに送信される） ---
        client = build_api_client(args.engine)    # 接続オブジェクトを作る（設定不足ならここで終了）
        model_name = "whisper-1" if args.engine == "openai" else os.environ["AZURE_OPENAI_DEPLOYMENT"]  # Azureはデプロイ名
        with tempfile.TemporaryDirectory() as tmp:  # 分割ファイル用の一時フォルダ（ブロックを出ると自動削除）
            for i, f in enumerate(files):         # 番号 i とファイル f を同時に取り出す
                print(f"処理中: {f.name}")        # どのファイルを処理中か表示する
                targets = [f]                     # 通常は、そのファイルをそのまま送る
                if f.stat().st_size > MAX_BYTES:  # 25MB を超えている場合は、
                    print("  25MBを超えるため分割します")  # 分割することを知らせて、
                    targets = split_audio(f, Path(tmp) / f"{i:03d}")  # ffmpeg で分割したファイルに置き換える
                texts = [transcribe_api(client, model_name, t, args.prompt) for t in targets]  # 各ファイルを順に文字起こし
                sections.append((f.name, "\n".join(texts)))  # 分割分を改行でつないで保存する

    body = "\n\n".join(                           # 全ファイルの結果を、空行区切りで1つの文字列にする
        (f"=== {name} ===\n{text}" if len(files) > 1 else text)  # 複数ファイルのときだけ見出しを付ける
        for name, text in sections                # 保存しておいた結果を1件ずつ取り出す
    )                                             # 結合はここまで
    out_dir = Path("out")                         # 出力先フォルダを「out」にする
    out_dir.mkdir(exist_ok=True)                  # フォルダを作る（既にあってもエラーにしない）
    out = out_dir / f"{Path(args.target).stem}.txt"  # 出力ファイル名（入力名.txt）を決める
    out.write_text(body, encoding="utf-8")        # UTF-8 で書き出す（Windowsの文字化け防止）
    print(f"完了 → {out}")                        # 保存先を表示して終了する


if __name__ == "__main__":                        # このファイルを直接実行したときだけ、
    main()                                        # main 関数を呼び出す（import されたときは動かさない）
